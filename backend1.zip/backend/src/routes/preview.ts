import express from "express";

const router = express.Router();

router.post("/generate-preview", async (req, res) => {
  const { prompt } = req.body;
  
  if (!prompt) {
    return res.status(400).json({ error: "Prompt is required" });
  }

  // Simulating AI Video Generation (Replace this with actual AI API call)
  const sampleVideoUrl = "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4";

  return res.json({ videoUrl: sampleVideoUrl });
});

export default router;
