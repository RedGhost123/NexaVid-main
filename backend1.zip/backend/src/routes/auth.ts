import express from "express";
import passport from "passport";
import "../config/passport"; // Ensure passport strategies are loaded

import {
  register,
  login,
  requestPasswordReset,
  resetPassword,
  enable2FA,
  verify2FA,
} from "../controllers/authController";

import { authMiddleware } from "../middlewares/authMiddleware";
import { loginRateLimiter } from "../middlewares/rateLimit";
import { verifyRecaptcha } from "../middlewares/recaptcha";

const router = express.Router();

// 🔹 Email & Password Authentication
router.post("/register", register);
router.post("/login", loginRateLimiter, verifyRecaptcha, login);

// 🔹 Password Reset
router.post("/forgot-password", requestPasswordReset);
router.post("/reset-password/:token", resetPassword);

// 🔹 Two-Factor Authentication (2FA)
router.post("/enable-2fa", authMiddleware, enable2FA);
router.post("/verify-2fa", authMiddleware, verify2FA);

// 🔹 Google Authentication
router.get("/google", passport.authenticate("google", { scope: ["profile", "email"] }));
router.get(
  "/google/callback",
  passport.authenticate("google", { session: false }),
  (req, res) => {
    res.json({ message: "Google login successful", user: req.user });
  }
);

// 🔹 Facebook Authentication
router.get("/facebook", passport.authenticate("facebook", { scope: ["email"] }));
router.get(
  "/facebook/callback",
  passport.authenticate("facebook", { session: false }),
  (req, res) => {
    res.json({ message: "Facebook login successful", user: req.user });
  }
);

// 🔹 Twitter Authentication
router.get("/twitter", passport.authenticate("twitter"));
router.get(
  "/twitter/callback",
  passport.authenticate("twitter", { session: false }),
  (req, res) => {
    res.json({ message: "Twitter login successful", user: req.user });
  }
);

export default router;
