import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import * as cors from "cors";
import { SwaggerModule, DocumentBuilder } from "@nestjs/swagger";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // 🔹 Enable CORS
  app.use(
    cors({
      origin: ["http://localhost:3000", "https://your-production-domain.com"],
      credentials: true,
    })
  );
  app.enableCors();

  // 🔹 Swagger setup
  const config = new DocumentBuilder()
    .setTitle("NexaVid API")
    .setDescription("The NexaVid API Documentation")
    .setVersion("1.0")
    .addBearerAuth()
    .build();
  
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("api", app, document);

  // Start the application on port 5000
  await app.listen(5000);
}

bootstrap();
