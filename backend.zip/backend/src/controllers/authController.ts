// src/controllers/authController.js
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET;

exports.register = async (req, res) => {
    const { fullName, email, password } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await prisma.user.create({
            data: { fullName, email, password: hashedPassword },
        });

        const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

        res.status(201).json({ message: "User registered!", token });
    } catch (error) {
        res.status(500).json({ error: "Registration failed" });
    }
};


// userlogin

exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await prisma.user.findUnique({ where: { email } });

        if (!user) return res.status(404).json({ error: "User not found" });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

        const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

        res.json({ message: "Login successful!", token });
    } catch (error) {
        res.status(500).json({ error: "Login failed" });
    }
};

//2fa login  

exports.login = async (req, res) => {
  const { email, password, otp } = req.body;

  try {
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) return res.status(404).json({ error: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

    if (user.twoFactorEnabled) {
      if (!otp) return res.status(400).json({ error: "OTP required" });

      const verified = speakeasy.totp.verify({
        secret: user.twoFactorSecret,
        encoding: "base32",
        token: otp,
      });

      if (!verified) return res.status(400).json({ error: "Invalid OTP" });
    }

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

    res.json({ message: "Login successful!", token });
  } catch (error) {
    res.status(500).json({ error: "Login failed" });
  }
};


// Password reset


const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { PrismaClient } = require("@prisma/client");
const { sendResetEmail } = require("../utils/emailService");


exports.requestPasswordReset = async (req, res) => {
  const { email } = req.body;

  try {
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) return res.status(404).json({ error: "User not found" });

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "15m" });

    const resetLink = `${process.env.FRONTEND_URL}/reset-password/${token}`;

    await sendResetEmail(email, resetLink);

    res.json({ message: "Password reset email sent!" });
  } catch (error) {
    res.status(500).json({ error: "Error sending password reset email" });
  }
};

exports.resetPassword = async (req, res) => {
  const { token } = req.params;
  const { newPassword } = req.body;

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
      where: { id: decoded.userId },
      data: { password: hashedPassword },
    });

    res.json({ message: "Password reset successful!" });
  } catch (error) {
    res.status(400).json({ error: "Invalid or expired token" });
  }
};



// Implement 2FA Setup & Verification


const speakeasy = require("speakeasy");
const qrcode = require("qrcode");

exports.enable2FA = async (req, res) => {
  const { userId } = req.user; 

  try {
    const secret = speakeasy.generateSecret({ length: 20 });

    await prisma.user.update({
      where: { id: userId },
      data: { twoFactorSecret: secret.base32, twoFactorEnabled: true },
    });

    const qrCodeUrl = await qrcode.toDataURL(secret.otpauth_url);

    res.json({ message: "2FA enabled", qrCodeUrl });
  } catch (error) {
    res.status(500).json({ error: "Error enabling 2FA" });
  }
};



//Verify OTP on Login

exports.verify2FA = async (req, res) => {
  const { userId } = req.user;
  const { otp } = req.body;

  try {
    const user = await prisma.user.findUnique({ where: { id: userId } });

    if (!user || !user.twoFactorEnabled) {
      return res.status(400).json({ error: "2FA is not enabled" });
    }

    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: "base32",
      token: otp,
    });

    if (!verified) return res.status(400).json({ error: "Invalid OTP" });

    res.json({ message: "2FA verification successful!" });
  } catch (error) {
    res.status(500).json({ error: "Error verifying 2FA" });
  }
};



// Implement Failed Login Tracking & Account Locking
// src/controllers/authController.js


const geoip = require("geoip-lite");
const { PrismaClient } = require("@prisma/client");


const MAX_FAILED_ATTEMPTS = 5;

exports.login = async (req, res) => {
  const { email, password, otp } = req.body;
  const ip = req.ip;
  const geo = geoip.lookup(ip);

  try {
    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) return res.status(404).json({ error: "User not found" });

    // Check if account is locked
    if (user.isLocked) return res.status(403).json({ error: "Account locked due to multiple failed attempts" });

    const isMatch = await bcrypt.compare(password, user.password);
    
    if (!isMatch) {
      // Track failed login attempts
      await prisma.user.update({
        where: { email },
        data: {
          failedLoginAttempts: user.failedLoginAttempts + 1,
          lastFailedLoginAt: new Date(),
        },
      });

      if (user.failedLoginAttempts + 1 >= MAX_FAILED_ATTEMPTS) {
        await prisma.user.update({
          where: { email },
          data: { isLocked: true },
        });
      }

      return res.status(400).json({ error: "Invalid credentials" });
    }

    // Reset failed attempts after successful login
    await prisma.user.update({
      where: { email },
      data: { failedLoginAttempts: 0, isLocked: false },
    });

    // Log user location & IP
    await prisma.user.update({
      where: { email },
      data: {
        lastLoginIp: ip,
        lastLoginLocation: geo ? `${geo.city}, ${geo.country}` : "Unknown",
      },
    });

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: "7d" });

    res.json({ message: "Login successful!", token });
  } catch (error) {
    res.status(500).json({ error: "Login failed" });
  }
};

// Request OTP API (Send OTP to Email)

app.post("/api/auth/request-otp", async (req, res) => {
  const { email } = req.body;
  const otp = Math.floor(100000 + Math.random() * 900000); // Generate 6-digit OTP
  await sendEmail(email, `Your OTP Code: ${otp}`); // Function to send email
  res.json({ message: "OTP sent to your email." });
});

// Verify OTP API

app.post("/api/auth/verify-otp", (req, res) => {
  const { email, otp } = req.body;
  if (otp === storedOtp) {
    res.json({ message: "OTP verified. 2FA enabled!" });
  } else {
    res.status(400).json({ error: "Invalid OTP" });
  }
});
