import { RecaptchaV2 } from "express-recaptcha";

const recaptcha = new RecaptchaV2(process.env.RECAPTCHA_SITE_KEY, process.env.RECAPTCHA_SECRET_KEY);

export const verifyRecaptcha = (req, res, next) => {
  recaptcha.verify(req, (error, data) => {
    if (error) return res.status(400).json({ error: "reCAPTCHA verification failed" });
    next();
  });
};
