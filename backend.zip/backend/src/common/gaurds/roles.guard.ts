import { Injectable, CanActivate, ExecutionContext } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { Observable } from "rxjs";
import { JwtService } from "@nestjs/jwt"; // Assuming you're using JWT for authentication

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector, private jwtService: JwtService) {}

  canActivate(
    context: ExecutionContext
  ): boolean | Promise<boolean> | Observable<boolean> {
    const requiredRoles = this.reflector.get<string[]>("roles", context.getHandler());
    if (!requiredRoles) {
      return true; // No role required for this route
    }

    const request = context.switchToHttp().getRequest();
    const user = request.user; // Make sure this user is added after authentication (e.g., in a JWT strategy)

    if (!user) {
      return false; // If no user, deny access
    }

    return requiredRoles.some(role => user.roles?.includes(role)); // Check if user's roles match required roles
  }
}
