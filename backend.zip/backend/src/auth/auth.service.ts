import { Injectable } from "@nestjs/common";
import { UserService } from "../user/user.service";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from "bcryptjs";
import * as speakeasy from "speakeasy";
import * as QRCode from "qrcode";
import { sendPasswordResetEmail } from "../utils/email.service";

@Injectable()
export class AuthService {
  constructor(private userService: UserService, private jwtService: JwtService) {}

  // 🔹 Validate User for Email/Password Authentication
  async validateUser(email: string, password: string) {
    const user = await this.userService.findByEmail(email);
    if (user && (await bcrypt.compare(password, user.password))) {
      return user;
    }
    return null;
  }

  // 🔹 Generate JWT Token
  async generateJwt(user: any) {
    const payload = {
      id: user.id,
      email: user.email,  // Add additional claims if necessary
      name: user.name,
    };
    return this.jwtService.sign(payload);
  }

  // 🔹 OAuth Login (Google/Facebook/Twitter)
  async validateOAuthLogin(profile: any, provider: string) {
    const email = profile.emails[0].value;
    let user = await this.userService.findByEmail(email);

    if (!user) {
      user = await this.userService.createUser(email, null, provider, profile.id);
    }

    return this.generateJwt(user); // Generate JWT after OAuth login
  }

  // 🔹 Generate 2FA Secret
  async generateTwoFactorAuthSecret(userEmail: string) {
    const secret = speakeasy.generateSecret({ name: `NexaVid (${userEmail})` });

    await this.userService.updateUser(userEmail, { twoFactorSecret: secret.base32 });

    // Return QR code data URL for 2FA setup
    return QRCode.toDataURL(secret.otpauth_url);
  }

  // 🔹 Validate 2FA Token
  async validateTwoFactorToken(userEmail: string, token: string) {
    const user = await this.userService.findByEmail(userEmail);
    return speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: "base32",
      token,
    });
  }

  // 🔹 Send Password Reset Email
  async sendPasswordResetEmail(email: string) {
    const token = this.generatePasswordResetToken(email);
    const resetLink = `http://localhost:5000/reset-password/${token}`;
    await sendPasswordResetEmail(email, resetLink);
  }

  // 🔹 Reset User Password
  async resetPassword(token: string, newPassword: string) {
    const email = this.verifyPasswordResetToken(token);

    if (!email) {
      throw new Error("Invalid or expired password reset token");
    }

    const hashedPassword = await bcrypt.hash(newPassword, 12);
    await this.userService.updateUser(email, { password: hashedPassword });
  }

  // 🔹 Generate Password Reset Token (Utility function)
  private generatePasswordResetToken(email: string): string {
    // Implement your token generation logic here (e.g., JWT, random string, etc.)
    return "random-token";  // Replace with actual logic
  }

  // 🔹 Verify Password Reset Token (Utility function)
  private verifyPasswordResetToken(token: string): string | null {
    // Implement token verification logic (e.g., decode JWT or check expiration)
    return "user-email@example.com"; // Replace with actual logic
  }
}
