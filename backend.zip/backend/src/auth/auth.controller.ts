import { Controller, Post, Body, Get, Param, UseGuards, Req, Res } from "@nestjs/common";
import { AuthService } from "./auth.service";
import { RegisterDto } from "./dto/register.dto";
import { UserService } from "../user/user.service";
import { AuthGuard } from "@nestjs/passport";
import { JwtService } from "@nestjs/jwt"; // Import JwtService if using it for token generation

@Controller("auth")
export class AuthController {
  constructor(
    private authService: AuthService,
    private userService: UserService,
    private jwtService: JwtService // Inject JwtService
  ) {}

  @Post("register")
  async register(@Body() dto: RegisterDto) {
    // Register a new user
    return this.userService.createUser(dto.email, dto.password);
  }

  // 🔹 Google Authentication
  @Get("google")
  @UseGuards(AuthGuard("google"))
  async googleAuth() {
    // This triggers the Google OAuth flow
  }

  @Get("google/callback")
  @UseGuards(AuthGuard("google"))
  async googleAuthRedirect(@Req() req, @Res() res) {
    // Generate JWT for the authenticated user and redirect to dashboard
    const token = await this.authService.generateJwt(req.user);
    return res.redirect(`http://localhost:3000/dashboard?token=${token}`);
  }

  // 🔹 Two-Factor Authentication (2FA)
  @Post("2fa/generate")
  async generateTwoFA(@Body("email") email: string) {
    // Generate and send 2FA secret
    return this.authService.generateTwoFactorAuthSecret(email);
  }

  @Post("2fa/verify")
  async verifyTwoFA(@Body() body: { email: string; token: string }) {
    // Verify the provided 2FA token
    return this.authService.validateTwoFactorToken(body.email, body.token);
  }

  // 🔹 Password Reset
  @Post("forgot-password")
  async forgotPassword(@Body("email") email: string) {
    // Send password reset email
    await this.authService.sendPasswordResetEmail(email);
    return { message: "Password reset link has been sent to your email." };
  }

  @Post("reset-password/:token")
  async resetPassword(@Param("token") token: string, @Body("password") password: string) {
    // Reset the password using the token
    await this.authService.resetPassword(token, password);
    return { message: "Password has been reset successfully." };
  }
}
