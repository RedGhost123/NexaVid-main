// src/config/passport.ts
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as FacebookStrategy } from "passport-facebook";
import { Strategy as TwitterStrategy } from "passport-twitter";
import { PrismaClient } from "@prisma/client";
import { Request } from "express";
import dotenv from "dotenv";

dotenv.config();
const prisma = new PrismaClient();

interface Profile {
  id: string;
  displayName: string;
  emails?: { value: string }[];
}

interface DoneFunction {
  (error: any, user?: any): void;
}

// Google Strategy
passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID as string,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
      callbackURL: "/api/auth/google/callback",
    },
    async (_accessToken: string, _refreshToken: string, profile: Profile, done: DoneFunction) => {
      try {
        let user = await prisma.user.findUnique({
          where: { googleId: profile.id },
        });

        if (!user) {
          user = await prisma.user.create({
            data: {
              fullName: profile.displayName,
              email: profile.emails?.[0]?.value || "",
              googleId: profile.id,
            },
          });
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  )
);

// Facebook Strategy
passport.use(
  new FacebookStrategy(
    {
      clientID: process.env.FACEBOOK_CLIENT_ID as string,
      clientSecret: process.env.FACEBOOK_CLIENT_SECRET as string,
      callbackURL: "/api/auth/facebook/callback",
      profileFields: ["id", "displayName", "emails"],
    },
    async (_accessToken: string, _refreshToken: string, profile: Profile, done: DoneFunction) => {
      try {
        let user = await prisma.user.findUnique({
          where: { facebookId: profile.id },
        });

        if (!user) {
          user = await prisma.user.create({
            data: {
              fullName: profile.displayName,
              email: profile.emails?.[0]?.value || "",
              facebookId: profile.id,
            },
          });
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  )
);

// Twitter Strategy
passport.use(
  new TwitterStrategy(
    {
      consumerKey: process.env.TWITTER_CLIENT_ID as string,
      consumerSecret: process.env.TWITTER_CLIENT_SECRET as string,
      callbackURL: "/api/auth/twitter/callback",
      includeEmail: true,
    },
    async (_token: string, _tokenSecret: string, profile: Profile, done: DoneFunction) => {
      try {
        let user = await prisma.user.findUnique({
          where: { twitterId: profile.id },
        });

        if (!user) {
          user = await prisma.user.create({
            data: {
              fullName: profile.displayName,
              email: profile.emails?.[0]?.value || "",
              twitterId: profile.id,
            },
          });
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }
  )
);

// Serialize & Deserialize User
passport.serializeUser((user: any, done) => done(null, user.id));

passport.deserializeUser(async (id: string, done) => {
  try {
    const user = await prisma.user.findUnique({ where: { id } });
    done(null, user);
  } catch (error) {
    done(error);
  }
});

export default passport;
