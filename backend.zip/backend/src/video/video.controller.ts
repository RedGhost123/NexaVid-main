import { Controller, Post, Body, Get, Req, UseGuards } from "@nestjs/common";
import { VideoService } from "./video.service";
import { AuthGuard } from "@nestjs/passport"; // Assuming you're using Passport for authentication
import { IsString, IsNotEmpty } from "class-validator";

// DTO for creating video
class CreateVideoDto {
  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  description: string;
}

@Controller("videos")
@UseGuards(AuthGuard())  // Ensure that the user is authenticated
export class VideoController {
  constructor(private videoService: VideoService) {}

  // 🔹 Create a New Video
  @Post()
  async create(@Body() createVideoDto: CreateVideoDto, @Req() req) {
    const { title, description } = createVideoDto;
    const userId = req.user.id; // Ensure req.user.id is set after authentication
    return this.videoService.createVideo(userId, title, description);
  }

  // 🔹 Get Videos of the Current User
  @Get()
  async getUserVideos(@Req() req) {
    const userId = req.user.id; // Ensure req.user.id is set after authentication
    return this.videoService.getUserVideos(userId);
  }
}
