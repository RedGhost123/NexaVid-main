import { Injectable } from "@nestjs/common";
import { PrismaService } from "prisma/prisma.service"; // Assuming PrismaService is correctly imported
import { VideoProject } from "@prisma/client"; // This will be automatically typed based on your Prisma schema

@Injectable()
export class VideoService {
  constructor(private prisma: PrismaService) {}

  // 🔹 Create a New Video
  async createVideo(userId: string, title: string, description?: string): Promise<VideoProject> {
    if (!title) {
      throw new Error("Title is required.");
    }

    try {
      return await this.prisma.videoProject.create({
        data: { userId, title, description },
      });
    } catch (error) {
      throw new Error(`Error creating video: ${error.message}`);
    }
  }

  // 🔹 Get Videos for the Current User
  async getUserVideos(userId: string, skip: number = 0, take: number = 10): Promise<VideoProject[]> {
    try {
      return await this.prisma.videoProject.findMany({
        where: { userId },
        skip,
        take,
      });
    } catch (error) {
      throw new Error(`Error fetching videos: ${error.message}`);
    }
  }
}
