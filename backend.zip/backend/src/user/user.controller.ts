import { Controller, Get, Param, NotFoundException, UseGuards } from "@nestjs/common";
import { UserService } from "./user.service";
import { Roles } from "../common/decorators/roles.decorator";
import { RolesGuard } from "../common/guards/roles.guard";

@Controller("users")
export class UserController {
  constructor(private userService: UserService) {}

  // 🔹 Get User by Email
  @Get(":email")
  async getUser(@Param("email") email: string) {
    try {
      const user = await this.userService.findByEmail(email);
      if (!user) {
        throw new NotFoundException(`User with email ${email} not found.`);
      }
      return user;
    } catch (error) {
      // Add additional error handling (e.g., database connection errors)
      throw new NotFoundException("An error occurred while retrieving the user.");
    }
  }

  // 🔹 Example Admin-Only Endpoint (Protected by RolesGuard)
  @Get("admin")
  @UseGuards(RolesGuard)  // Make sure RolesGuard is working properly
  @Roles("ADMIN")
  async getAdminData() {
    return { message: "Welcome, Admin!" };
  }
}
